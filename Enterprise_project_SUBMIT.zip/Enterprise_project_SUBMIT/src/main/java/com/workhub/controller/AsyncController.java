package com.workhub.controller;

import com.workhub.service.AsyncTaskService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/async")
public class AsyncController {

    private final AsyncTaskService service;

    public AsyncController(AsyncTaskService service) {
        this.service = service;
    }

    @PostMapping("/task")
    public String sendTask(@RequestParam String msg) {
        service.processTask(msg);
        return "Task sent asynchronously";
    }
}