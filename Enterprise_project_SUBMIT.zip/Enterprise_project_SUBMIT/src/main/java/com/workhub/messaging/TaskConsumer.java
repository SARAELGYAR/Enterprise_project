package com.workhub.messaging;

import com.workhub.config.RabbitConfig;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class TaskConsumer {

    @RabbitListener(queues = RabbitConfig.QUEUE)
    public void receive(String msg) {
        System.out.println(" Async Received: " + msg);
    }
}
