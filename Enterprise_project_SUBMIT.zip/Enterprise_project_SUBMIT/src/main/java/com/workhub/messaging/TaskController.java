package com.workhub.messaging;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    private final TaskProducer producer;

    public TaskController(TaskProducer producer) {
        this.producer = producer;
    }

    @PostMapping("/async")
    public String send(@RequestBody String msg) {
        producer.send(msg);
        return "sent to queue";
    }
}
