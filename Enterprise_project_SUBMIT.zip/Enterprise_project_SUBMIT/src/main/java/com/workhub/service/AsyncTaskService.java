package com.workhub.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class AsyncTaskService {

    @Async
    public void processTask(String msg) {
        System.out.println(" START TASK: " + msg);

        try {
            Thread.sleep(3000);
        } catch (Exception e) {}

        System.out.println("DONE TASK: " + msg);
    }
}